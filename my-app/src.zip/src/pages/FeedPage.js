import React, { Component } from 'react';

import AxiosActions from '../services/AxiosActions';

import { Redirect } from 'react-router-dom';

import Fuse from 'fuse.js';



class FeedPage extends Component {
    //setting some states and var
    constructor(props) {
        super(props);
        this.message = null;
        this.state = {
            messages: [],
            users: [],
            displayedUsers: [],
            friends: [],
            redirect: false
        };
    }
    //trigger the logout method provided by the mighty back and redirect to the homepage
    disconnect = () => {
        AxiosActions.disconnect().then((results) => {
            if (results.data["Déconnexion"] === "ok")
                localStorage.clear();
            this.setState({
                redirect: true
            });
        });
    }
    //list all the messages and refresh the views
    listMessages = () => {
        return AxiosActions.listMessages().then((results) => {
            let k = Object.keys(results.data)[0];
            if (typeof (k) != "undefined") {
                return this.setState({
                    messages: results.data[k]
                });

            }

        });
    }
    //perform an Ajax call to the "mighty API" and list all the users
    listUser = () => {
        return AxiosActions.listUser().then((results) => {
            let c = Object.keys(results.data).map((key, index) => {
                return results.data[key]
            });
            let options = {
                //keys: ['title', 'author'
            }
            this.fuse = new Fuse(c, options)
            return this.setState({
                users: c,
                displayedUsers: c
            });
        });
    }
    //perform an Ajax call to the "mighty API" and list all the connected user's friends from the DB
    listFriends = () => {
        return AxiosActions.listFriends().then((results) => {
            return this.setState({
                friends: results.data.friends
            });
        });
    }
    //react lifecycle methods
    componentDidMount = () => {
        this.feedTheRenderMethod();
    }
    //make a lot of ajax request and rerender the view while you can, please.
    feedTheRenderMethod = () => {
        this.listMessages().then(() => {
            this.listUser().then(() => {
                this.listFriends().then((results) => {
                    console.log(results);
                })
            })
        });
    }
    //on textarea change, update the value of the this.message var
    onMessageChange = (element) => {
        this.message = element.target.value;
    }
    //perform an Ajax call to the "mighty API" and add a message to the DB
    addMessage = () => {
        let obj = {
            message: this.message
        }
        AxiosActions.addMessage(obj).then((results) => {
            //clear the texteArea input
            this.message = null;
            document.querySelector('.textAreaForMessage').value = null;
            this.listMessages();
        });

    }
    //below the addAFriend method
    addAFriend = (login) => {
        AxiosActions.addAFriend(login).then(() => { this.listFriends() });
    }
    //below the removeFriend method
    removeFriend = (friendLogin) => {
        AxiosActions.removeFriend(friendLogin).then(() => { this.listFriends() });
    }
    //search for a user and refresh the list
    searchUser = (element) => {
        let r = this.fuse.search(element.target.value);
        return this.setState({
            displayedUsers: r
        });
    }
    render() {

        if (this.state.redirect)
            return <Redirect to="/" />

        return (

            <div>

                <h1>FeedPage</h1>

                <textarea className="textAreaForMessage" onChange={this.onMessageChange} />

                <button onClick={this.addMessage}> Ajouter un message</button>

                <button onClick={this.disconnect}> Deconnexion</button>

                <div>
                    <h2>
                        LISTE USERS
                    </h2>
                    <input type="text" placeholder="Rechercher parmi les utilisateurs" onChange={this.searchUser} />
                    <ul>
                        {
                            this.state.users.map((user, index) => {
                                return (

                                    <li key={index}>{user}
                                        {

                                            <button onClick={() => this.addAFriend(user)}>Ajouter</button>
                                        }

                                    </li>
                                )
                            })
                        }
                    </ul>
                    <h2>
                        LISTE MESSAGES
                    </h2>
                    <ul>
                        {
                            this.state.messages.map((message, index) => <li key={index}>{message}</li>)
                        }
                    </ul>
                    <h2>
                        LISTE ami(s)
                    </h2>
                    <ul>
                        {
                            this.state.friends.map((friend, index) => <li key={index}>{friend} <button onClick={() => { this.removeFriend(friend) }}>Retirer du groupe d'ami</button></li>)
                        }
                    </ul>
                </div>
            </div>

        )



    }



}



export default FeedPage;


